# Changelog

## 1.5.0-rapid.2.0

### Added

- Added the `AIGatewayCustomPolicy` CRD, together with the RBAC rules the
  operator needs to reconcile it.
  [#5896](https://github.com/Kong/kong-operator/pull/5896)

### Changed

- Bump default image to 2.4.0-rapid.2.0

## 1.5.0-rapid.1

### Added

- Added CRDs for the new operator APIs: `OnPremAIGateway`,
  `AIGatewayCertificate`, `AIGatewayCACertificate`, `AIGatewaySNI`,
  `KonnectConfigStoreSync` and `DBBackedHybridControlPlane`, together with the
  RBAC rules the operator needs to reconcile them.
  [#5595](https://github.com/Kong/kong-operator/pull/5595),
  [#5656](https://github.com/Kong/kong-operator/pull/5656),
  [#5658](https://github.com/Kong/kong-operator/pull/5658),
  [#5667](https://github.com/Kong/kong-operator/pull/5667),
  [#5660](https://github.com/Kong/kong-operator/pull/5660),
  [#5773](https://github.com/Kong/kong-operator/pull/5773)

### Changed

- Bump default image to 2.4.0-rapid.1
- Bump Gateway API CRDs subcharts (`gwapi-standard-crds`, `gwapi-experimental-crds`)
  to `1.6.2`.
  [#5462](https://github.com/Kong/kong-operator/pull/5462)
- Strip the per-field `description` doc strings from the chart's copy of the
  operator CRDs. The CRDs ship as chart templates, so they are part of the Helm
  release manifest, which is stored gzip-compressed in a `Secret` capped at 1MiB.
  With `ko-crds.enabled=true` the manifest grew past that limit and
  `helm install`/`helm upgrade` failed with
  `Secret ... is invalid: data: Too long`. Dropping the doc strings takes the CRD
  set from 7.6MB to 2.9MB raw (743KB to 133KB compressed), which restores
  Helm-managed CRD installs and upgrades with enough headroom to spare.
  Note that `kubectl explain` no longer prints field documentation for CRDs
  installed through this chart. The published API reference is generated from
  `config/crd/kong-operator`, which is untouched. See
  [CRD field descriptions](UPGRADE.md#crd-field-descriptions) for how to
  install the CRDs with their field documentation.
  [#5819](https://github.com/Kong/kong-operator/pull/5819)

## 1.4.0

### Added

- Added `nodeSelector` value for the operator pod, mirroring the existing
  `tolerations` and `affinity` values.
  [#5246](https://github.com/Kong/kong-operator/pull/5246)

### Changed

- Bump default image to 2.3.0
- Bump operator's memory limits from `256Mi` to `512Mi` to prevent OOM issues
  with default settings in environments with a lot of cluster resources.
  [#5248](https://github.com/Kong/kong-operator/pull/5248)

## 1.3.1

### Changed

- Bump default image to 2.2.1

## 1.3.0

### Changed

- Bump default image to 2.2.0
- Bootstrapping CA certificate (that is used for signing certificates for
  ControlPlane - DataPlane communication) can be done by cert-manager,
  see the options `global.certificateAuthority.options.certManager.enabled`.
  [#3655](https://github.com/Kong/kong-operator/pull/3655)

### Fixes

- Allow `fullnameOverride` to control the webhook cert-manager `Certificate`
  and `Issuer` resource names.
  When `fullnameOverride` is aleady being used, the webhook certificate resources
  will be renamed which can cause intermittent webhook failures during upgrade.
  [#4091](https://github.com/Kong/kong-operator/pull/4091)

## 1.2.0

### Fixes

- Fix broken installations using `--generate-name` or provided too long release name,
  which caused the generated metrics `Service` name to exceed the 63 character limit.
  If you rely on metrics `Service` name in your integrations (e.g., for ServiceMonitor),
  please make sure to update it to match the new naming convention,
  which is `<release-name>-metrics` truncated to 63 characters if needed.
  [#3261](https://github.com/Kong/kong-operator/pull/3261)

## 1.1.1

### Fixes

- Fix an issue with missing volume mount when `ko-crds.enabled=false` is set
  and conversion webhook is enabled.
  [#3228](https://github.com/Kong/kong-operator/pull/3228)

## 1.1.0

### Changed

- Bootstrapping CA certificate (that is used for signing certificates for
  ControlPlane - DataPlane communication) is done automatically by Helm.
  The existing certificate can be referenced by setting options
  `certificateAuthority.secret.name` and `certificateAuthority.secret.namespace`.
  [#3084](https://github.com/Kong/kong-operator/pull/3084)
- Update Gateway API to 1.4.0
  [#2451](https://github.com/Kong/kong-operator/pull/2451)

## 1.0.2

### Fixes

- Use proper certificate for validating webhook when `cert-manager` is used.
  [#2356](https://github.com/Kong/kong-operator/pull/2356)
- Bump `ko-crds` subchart to `1.0.1`, which includes:
  - Add the `status.clusterType` field in `KonnectGatewayControlPlane` CRD.
    [#2311](https://github.com/Kong/kong-operator/pull/2311)

## 1.0.1

### Added

- Support for specifying image digest via `image.digest` in `values.yaml`
  [#2311](https://github.com/Kong/kong-operator/pull/2311)

## 1.0.0

This is the first release of the new Helm Chart dedicated to install
[Kong Operator](https://github.com/Kong/kong-operator), it uses
[v2.0.0](https://github.com/Kong/kong-operator/releases/tag/v2.0.0) image
for operator and `3.11` for Kong Gateway.

Read more about migration in the official docs.

### ⚠️ **IMPORTANT NOTICE ABOUT CONVERSION WEBHOOKS:**

Since conversion webhooks are bound to a CRD definition, installing more than 1
helm release has to be done with caution to avoid conflicts.

Users can use `ko-crds.enabled` to install and manage operator's CRDs.
`global.webhooks.conversion.enabled` can be set to `true` to enable the conversion webhook.
Any subsequent helm release after the first one that enables these options,
must not set either of these to `true` to prevent ownership conflicts.

Moreover, `env.enable_conversion_webhook` must be set to `false` in all
releases except the first one that enables it, otherwise operator deployments may fail.
The operator deployment that has been installed as first, will handle the conversions.
